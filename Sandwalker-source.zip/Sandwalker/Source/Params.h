#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>

namespace sw
{
enum P { osc1Wave, osc2Wave, osc2Detune, osc2Level, osc2Semi, subLevel, noiseLevel, unison, spread,
         cutoff, res, fltEnv, keyTrack, lfoRate, lfoDepth, lfoPitch,
         aA, aD, aS, aR, fA, fD, fS, fR,
         chorus, delayMix, delayTime, delayFb, reverbMix, reverbSize, master, numParams };

inline const char* const ids[numParams] = {
    "osc1Wave","osc2Wave","osc2Detune","osc2Level","osc2Semi","subLevel","noiseLevel","unison","spread",
    "cutoff","res","fltEnv","keyTrack","lfoRate","lfoDepth","lfoPitch",
    "aA","aD","aS","aR","fA","fD","fS","fR",
    "chorus","delayMix","delayTime","delayFb","reverbMix","reverbSize","master" };

inline const char* const names[numParams] = {
    "Osc1 Wave","Osc2 Wave","Detune","Osc2 Level","Osc2 Semi","Sub","Noise","Unison","Spread",
    "Cutoff","Reso","Env Amt","Key Trk","LFO Rate","LFO Filt","LFO Pitch",
    "Amp A","Amp D","Amp S","Amp R","Flt A","Flt D","Flt S","Flt R",
    "Chorus","Delay","Dly Time","Feedback","Reverb","Rev Size","Master" };
}
