#pragma once
#include <vector>
#include <utility>

struct Preset { const char* name; std::vector<std::pair<const char*, float>> values; };

inline const std::vector<Preset>& getPresets()
{
    static const std::vector<Preset> p = {
    { "Init", {} },
    // ---------------- PADS ----------------
    { "Pad - Oasis Drift", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",9},{"unison",3},{"spread",18},{"cutoff",1800},{"res",1},{"fltEnv",0.2f},{"aA",1.8f},{"aD",1},{"aS",0.8f},{"aR",3},{"fA",2},{"fD",2},{"fS",0.5f},{"fR",3},{"chorus",0.5f},{"reverbMix",0.45f},{"reverbSize",0.85f},{"lfoRate",0.3f},{"lfoDepth",0.15f}} },
    { "Pad - Mirage Choir", {{"osc1Wave",1},{"osc2Wave",0},{"osc2Semi",12},{"osc2Level",0.4f},{"unison",4},{"spread",14},{"cutoff",2500},{"aA",1.2f},{"aR",2.5f},{"chorus",0.6f},{"reverbMix",0.5f},{"reverbSize",0.8f}} },
    { "Pad - Dust Veil", {{"osc1Wave",2},{"osc2Wave",2},{"noiseLevel",0.08f},{"cutoff",900},{"res",1.5f},{"fltEnv",0.4f},{"lfoDepth",0.25f},{"lfoRate",0.15f},{"aA",2.5f},{"aR",4},{"reverbMix",0.6f},{"reverbSize",0.9f}} },
    { "Pad - Nomad Strings", {{"osc1Wave",2},{"osc2Wave",2},{"unison",5},{"spread",22},{"cutoff",3200},{"aA",0.6f},{"aS",0.9f},{"aR",1.5f},{"chorus",0.6f},{"reverbMix",0.35f}} },
    { "Pad - Salt Flats", {{"osc1Wave",3},{"osc2Wave",1},{"cutoff",1400},{"res",2},{"lfoDepth",0.2f},{"lfoRate",0.4f},{"aA",1},{"aR",2},{"reverbMix",0.4f},{"delayMix",0.25f},{"delayTime",0.5f},{"delayFb",0.45f}} },
    { "Pad - Midnight Bazaar", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Semi",7},{"osc2Level",0.5f},{"unison",2},{"cutoff",1100},{"res",1.8f},{"fltEnv",0.5f},{"fD",1.5f},{"fS",0.2f},{"aA",0.4f},{"aR",1.5f},{"delayMix",0.3f},{"delayTime",0.375f},{"reverbMix",0.4f}} },
    { "Pad - Ancient Sky", {{"osc1Wave",0},{"osc2Wave",1},{"osc2Semi",12},{"cutoff",5000},{"aA",3},{"aR",5},{"reverbMix",0.7f},{"reverbSize",0.95f},{"chorus",0.4f}} },
    { "Pad - Sirocco Wind", {{"osc1Wave",1},{"osc2Level",0},{"noiseLevel",0.5f},{"cutoff",1800},{"res",3},{"lfoDepth",0.6f},{"lfoRate",0.2f},{"aA",3},{"aR",4},{"reverbMix",0.6f}} },
    // ---------------- PLUCKS ----------------
    { "Pluck - Oud", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",4},{"cutoff",700},{"res",1.5f},{"fltEnv",0.8f},{"fD",0.25f},{"fS",0},{"aA",0.002f},{"aD",0.6f},{"aS",0},{"aR",0.4f},{"reverbMix",0.3f},{"delayMix",0.15f}} },
    { "Pluck - Qanun Glass", {{"osc1Wave",1},{"osc2Wave",0},{"osc2Semi",12},{"osc2Level",0.5f},{"cutoff",4000},{"fltEnv",0.3f},{"fD",0.3f},{"fS",0},{"aA",0.002f},{"aD",0.9f},{"aS",0},{"aR",0.6f},{"reverbMix",0.35f},{"delayMix",0.3f},{"delayTime",0.375f}} },
    { "Pluck - Kalimba Dust", {{"osc1Wave",0},{"osc2Wave",1},{"osc2Semi",12},{"osc2Level",0.3f},{"cutoff",5000},{"aA",0.002f},{"aD",0.5f},{"aS",0},{"aR",0.5f},{"reverbMix",0.4f}} },
    { "Pluck - Bazaar", {{"osc1Wave",3},{"osc2Level",0},{"cutoff",900},{"res",2.5f},{"fltEnv",0.9f},{"fD",0.2f},{"fS",0},{"aA",0.002f},{"aD",0.35f},{"aS",0},{"aR",0.2f},{"delayMix",0.3f},{"delayTime",0.375f}} },
    { "Pluck - Desert Harp", {{"osc1Wave",2},{"osc2Wave",2},{"unison",2},{"spread",8},{"cutoff",2500},{"fltEnv",0.5f},{"fD",0.5f},{"fS",0},{"aA",0.002f},{"aD",1.2f},{"aS",0},{"aR",1},{"reverbMix",0.5f},{"chorus",0.3f}} },
    { "Pluck - Frame Drum Tone", {{"osc1Wave",0},{"osc2Level",0},{"subLevel",0.8f},{"noiseLevel",0.1f},{"cutoff",600},{"fltEnv",0.5f},{"fD",0.15f},{"fS",0},{"aA",0.001f},{"aD",0.2f},{"aS",0},{"aR",0.15f},{"reverbMix",0.2f}} },
    // ---------------- LEADS ----------------
    { "Lead - Nomad", {{"osc1Wave",2},{"osc2Wave",2},{"unison",3},{"spread",10},{"cutoff",3500},{"res",1.2f},{"fltEnv",0.3f},{"aA",0.01f},{"aS",0.9f},{"aR",0.4f},{"lfoPitch",0.25f},{"lfoRate",5.5f},{"delayMix",0.3f},{"reverbMix",0.3f}} },
    { "Lead - Ney Whisper", {{"osc1Wave",1},{"osc2Level",0},{"noiseLevel",0.06f},{"cutoff",3000},{"aA",0.08f},{"aS",0.9f},{"aR",0.3f},{"lfoPitch",0.4f},{"lfoRate",5},{"reverbMix",0.4f}} },
    { "Lead - Sand Square", {{"osc1Wave",3},{"osc2Wave",3},{"osc2Semi",12},{"osc2Level",0.3f},{"cutoff",2800},{"res",1.5f},{"aA",0.01f},{"aS",0.85f},{"aR",0.3f},{"delayMix",0.25f},{"reverbMix",0.25f}} },
    { "Lead - Caravan Saw", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",12},{"unison",2},{"cutoff",5000},{"aR",0.5f},{"chorus",0.4f},{"delayMix",0.35f},{"delayTime",0.375f},{"reverbMix",0.3f}} },
    { "Lead - Zurna Cry", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Semi",7},{"cutoff",2200},{"res",3.5f},{"fltEnv",0.5f},{"fD",0.3f},{"fS",0.6f},{"lfoPitch",0.3f},{"lfoRate",5.5f},{"aA",0.02f},{"aS",0.9f},{"reverbMix",0.3f}} },
    { "Lead - Silk Voice", {{"osc1Wave",1},{"osc2Wave",0},{"osc2Semi",12},{"cutoff",4500},{"aA",0.15f},{"aS",0.9f},{"aR",0.5f},{"lfoPitch",0.3f},{"lfoRate",5.5f},{"reverbMix",0.45f}} },
    // ---------------- BASS ----------------
    { "Bass - Deep Sub", {{"osc1Wave",0},{"osc2Level",0},{"subLevel",0.7f},{"cutoff",600},{"aA",0.005f},{"aS",1},{"aR",0.2f}} },
    { "Bass - Gnaw", {{"osc1Wave",2},{"osc2Wave",3},{"subLevel",0.5f},{"cutoff",500},{"res",2.5f},{"fltEnv",0.6f},{"fD",0.3f},{"fS",0.3f},{"aA",0.003f},{"aS",0.9f},{"aR",0.15f}} },
    { "Bass - Tribal", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Semi",-12},{"osc2Level",0.8f},{"cutoff",450},{"res",2},{"fltEnv",0.7f},{"fD",0.2f},{"fS",0.2f},{"aA",0.003f},{"aD",0.4f},{"aS",0.6f},{"aR",0.2f}} },
    { "Bass - Rumble Drone", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",5},{"unison",3},{"spread",8},{"subLevel",0.6f},{"cutoff",350},{"lfoDepth",0.3f},{"lfoRate",0.2f},{"aA",0.4f},{"aS",1},{"aR",1.2f}} },
    { "Bass - Pulse", {{"osc1Wave",3},{"osc2Level",0},{"cutoff",700},{"res",3},{"fltEnv",0.8f},{"fD",0.15f},{"fS",0},{"aA",0.002f},{"aD",0.2f},{"aS",0.5f},{"aR",0.1f}} },
    { "Bass - Sub Heart", {{"osc1Wave",0},{"osc2Wave",0},{"osc2Semi",-12},{"osc2Level",0.6f},{"subLevel",0.9f},{"cutoff",400},{"aA",0.01f},{"aS",1},{"aR",0.3f}} },
    // ---------------- TEXTURES / ARP-FRIENDLY ----------------
    { "Tex - Heat Haze", {{"osc1Wave",2},{"noiseLevel",0.3f},{"cutoff",2000},{"res",2},{"lfoDepth",0.5f},{"lfoRate",6},{"aA",1.5f},{"aR",3},{"reverbMix",0.5f},{"chorus",0.4f}} },
    { "Arp - Tidal Pluck", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",6},{"cutoff",1500},{"fltEnv",0.7f},{"fD",0.18f},{"fS",0},{"aA",0.002f},{"aD",0.25f},{"aS",0},{"aR",0.2f},{"delayMix",0.45f},{"delayTime",0.375f},{"delayFb",0.5f},{"reverbMix",0.35f}} },
    { "Arp - Glass Steps", {{"osc1Wave",1},{"osc2Wave",0},{"osc2Semi",12},{"osc2Level",0.6f},{"cutoff",6000},{"aA",0.002f},{"aD",0.3f},{"aS",0},{"aR",0.3f},{"delayMix",0.4f},{"delayTime",0.25f},{"delayFb",0.5f},{"reverbMix",0.4f}} },
    { "Bell - Mystic", {{"osc1Wave",0},{"osc2Wave",0},{"osc2Semi",19},{"osc2Level",0.5f},{"cutoff",8000},{"aA",0.002f},{"aD",2},{"aS",0},{"aR",2},{"reverbMix",0.6f},{"reverbSize",0.9f}} },
    { "Tex - Dark Ritual", {{"osc1Wave",2},{"osc2Wave",2},{"osc2Semi",-5},{"unison",5},{"spread",35},{"cutoff",700},{"res",2.5f},{"lfoDepth",0.4f},{"lfoRate",0.12f},{"aA",2},{"aR",4},{"reverbMix",0.6f}} },
    { "Arp - Echo Canyon", {{"osc1Wave",2},{"osc2Level",0},{"cutoff",1800},{"fltEnv",0.6f},{"fD",0.2f},{"fS",0},{"aA",0.002f},{"aD",0.3f},{"aS",0},{"aR",0.3f},{"delayMix",0.5f},{"delayTime",0.5f},{"delayFb",0.65f},{"reverbMix",0.5f}} },
    };
    return p;
}
