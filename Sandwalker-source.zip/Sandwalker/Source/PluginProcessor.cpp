#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Voice.h"
#include "Presets.h"

SandwalkerProcessor::SandwalkerProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    for (int i = 0; i < 8; ++i) synth.addVoice (new sw::Voice (apvts));
    synth.addSound (new sw::Sound());
}

juce::AudioProcessorValueTreeState::ParameterLayout SandwalkerProcessor::createLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> v;

    auto F = [&] (sw::P p, float lo, float hi, float def, float skew = 1.0f)
    { v.push_back (std::make_unique<AudioParameterFloat> (ParameterID { sw::ids[p], 1 }, sw::names[p],
                                                          NormalisableRange<float> (lo, hi, 0.0f, skew), def)); };
    auto C = [&] (sw::P p, int def)
    { v.push_back (std::make_unique<AudioParameterChoice> (ParameterID { sw::ids[p], 1 }, sw::names[p],
                                                           StringArray { "Sine", "Tri", "Saw", "Square" }, def)); };
    auto I = [&] (sw::P p, int lo, int hi, int def)
    { v.push_back (std::make_unique<AudioParameterInt> (ParameterID { sw::ids[p], 1 }, sw::names[p], lo, hi, def)); };

    C (sw::osc1Wave, 2); C (sw::osc2Wave, 2);
    F (sw::osc2Detune, -100, 100, 7); F (sw::osc2Level, 0, 1, 0.6f); I (sw::osc2Semi, -24, 24, 0);
    F (sw::subLevel, 0, 1, 0); F (sw::noiseLevel, 0, 1, 0);
    I (sw::unison, 1, 5, 1); F (sw::spread, 0, 60, 12);
    F (sw::cutoff, 20, 20000, 8000, 0.3f); F (sw::res, 0.5f, 8, 0.8f);
    F (sw::fltEnv, -1, 1, 0.3f); F (sw::keyTrack, 0, 1, 0.3f);
    F (sw::lfoRate, 0.05f, 20, 4, 0.4f); F (sw::lfoDepth, 0, 1, 0); F (sw::lfoPitch, 0, 1, 0);
    F (sw::aA, 0.001f, 8, 0.01f, 0.35f); F (sw::aD, 0.001f, 8, 0.3f, 0.35f);
    F (sw::aS, 0, 1, 0.8f);              F (sw::aR, 0.005f, 10, 0.3f, 0.35f);
    F (sw::fA, 0.001f, 8, 0.01f, 0.35f); F (sw::fD, 0.001f, 8, 0.4f, 0.35f);
    F (sw::fS, 0, 1, 0.3f);              F (sw::fR, 0.005f, 10, 0.3f, 0.35f);
    F (sw::chorus, 0, 1, 0.2f);
    F (sw::delayMix, 0, 1, 0); F (sw::delayTime, 0.05f, 1.0f, 0.375f); F (sw::delayFb, 0, 0.9f, 0.35f);
    F (sw::reverbMix, 0, 1, 0.2f); F (sw::reverbSize, 0, 1, 0.6f);
    F (sw::master, 0, 1, 0.7f);

    return { v.begin(), v.end() };
}

void SandwalkerProcessor::prepareToPlay (double sampleRate, int blockSize)
{
    sr = sampleRate;
    synth.setCurrentPlaybackSampleRate (sampleRate);
    chorus.prepare ({ sampleRate, (juce::uint32) blockSize, 2 });
    chorus.setRate (0.8f); chorus.setDepth (0.3f); chorus.setCentreDelay (7.0f); chorus.setFeedback (0.0f);
    reverb.setSampleRate (sampleRate); reverb.reset();
    for (auto& b : dbuf) b.assign ((size_t) (sampleRate * 1.2) + 2, 0.0f);
    wpos = 0;
}

void SandwalkerProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    buffer.clear();
    synth.renderNextBlock (buffer, midi, 0, n);

    // Chorus
    chorus.setMix (val (sw::chorus));
    { juce::dsp::AudioBlock<float> blk (buffer); juce::dsp::ProcessContextReplacing<float> ctx (blk); chorus.process (ctx); }

    // Delay
    const float dMix = val (sw::delayMix);
    if (dMix > 0.001f)
    {
        const int size = (int) dbuf[0].size();
        const int ds = juce::jlimit (1, size - 1, (int) (val (sw::delayTime) * sr));
        const float fb = val (sw::delayFb);
        for (int i = 0; i < n; ++i)
        {
            const int rp = (wpos - ds + size) % size;
            for (int ch = 0; ch < 2; ++ch)
            {
                float* d = buffer.getWritePointer (ch);
                const float in = d[i], del = dbuf[(size_t) ch][(size_t) rp];
                dbuf[(size_t) ch][(size_t) wpos] = in + del * fb;
                d[i] = in + del * dMix;
            }
            wpos = (wpos + 1) % size;
        }
    }

    // Reverb
    const float rMix = val (sw::reverbMix);
    if (rMix > 0.001f)
    {
        juce::Reverb::Parameters rp;
        rp.roomSize = val (sw::reverbSize); rp.damping = 0.45f; rp.width = 1.0f;
        rp.wetLevel = rMix * 0.5f; rp.dryLevel = 1.0f - rMix * 0.3f; rp.freezeMode = 0.0f;
        reverb.setParameters (rp);
        reverb.processStereo (buffer.getWritePointer (0), buffer.getWritePointer (1), n);
    }

    const float m = val (sw::master);
    buffer.applyGain (m * m * 1.6f);
}

int SandwalkerProcessor::getNumPrograms() { return (int) getPresets().size(); }
const juce::String SandwalkerProcessor::getProgramName (int i)
{ return (i >= 0 && i < getNumPrograms()) ? getPresets()[(size_t) i].name : juce::String(); }

void SandwalkerProcessor::setCurrentProgram (int i)
{
    if (i < 0 || i >= getNumPrograms()) return;
    currentProgram = i;
    for (int k = 0; k < sw::numParams; ++k)
        if (auto* p = apvts.getParameter (sw::ids[k])) p->setValueNotifyingHost (p->getDefaultValue());
    for (auto& kv : getPresets()[(size_t) i].values)
        if (auto* p = apvts.getParameter (kv.first)) p->setValueNotifyingHost (p->convertTo0to1 (kv.second));
}

void SandwalkerProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    state.setProperty ("program", currentProgram, nullptr);
    if (auto xml = state.createXml()) copyXmlToBinary (*xml, dest);
}

void SandwalkerProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
        {
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
            currentProgram = juce::jlimit (0, getNumPrograms() - 1, (int) apvts.state.getProperty ("program", 0));
        }
}

juce::AudioProcessorEditor* SandwalkerProcessor::createEditor() { return new SandwalkerEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SandwalkerProcessor(); }
