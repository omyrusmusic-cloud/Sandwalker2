#pragma once
#include "Params.h"

namespace sw
{
struct Sound : juce::SynthesiserSound
{
    bool appliesToNote (int) override { return true; }
    bool appliesToChannel (int) override { return true; }
};

inline float polyBlep (float t, float dt)
{
    if (t < dt)        { t /= dt;               return t + t - t * t - 1.0f; }
    if (t > 1.0f - dt) { t = (t - 1.0f) / dt;   return t * t + t + t + 1.0f; }
    return 0.0f;
}

inline float oscSample (int wave, float& ph, float dt)
{
    float v;
    switch (wave)
    {
        case 0:  v = std::sin (juce::MathConstants<float>::twoPi * ph); break;
        case 1:  v = 4.0f * std::abs (ph - 0.5f) - 1.0f; v = -v; break;
        case 2:  v = 2.0f * ph - 1.0f - polyBlep (ph, dt); break;
        default: { float p2 = ph + 0.5f; if (p2 >= 1.0f) p2 -= 1.0f;
                   v = (ph < 0.5f ? 1.0f : -1.0f) + polyBlep (ph, dt) - polyBlep (p2, dt); }
    }
    ph += dt; if (ph >= 1.0f) ph -= 1.0f;
    return v;
}

class Voice : public juce::SynthesiserVoice
{
public:
    explicit Voice (juce::AudioProcessorValueTreeState& a)
    {
        for (int i = 0; i < numParams; ++i) ptr[i] = a.getRawParameterValue (ids[i]);
    }

    bool canPlaySound (juce::SynthesiserSound* s) override { return dynamic_cast<Sound*> (s) != nullptr; }

    void setCurrentPlaybackSampleRate (double sr) override
    {
        juce::SynthesiserVoice::setCurrentPlaybackSampleRate (sr);
        juce::dsp::ProcessSpec spec { sr, 512, 1 };
        for (auto& f : filt) { f.prepare (spec); f.setType (juce::dsp::StateVariableTPTFilterType::lowpass); }
        ampEnv.setSampleRate (sr); fltEnvl.setSampleRate (sr);
    }

    void startNote (int midiNote, float velocity, juce::SynthesiserSound*, int pitchWheel) override
    {
        baseNote = (float) midiNote; vel = velocity;
        bend = (pitchWheel - 8192) / 8192.0f * 2.0f;
        const bool multi = (int) v (unison) > 1;
        for (int u = 0; u < 5; ++u) { ph1[u] = multi ? rng.nextFloat() : 0.0f; ph2[u] = multi ? rng.nextFloat() : 0.0f; }
        subPh = 0.0f; lfoPh = 0.0f;
        for (auto& f : filt) f.reset();
        updateEnvs();
        ampEnv.noteOn(); fltEnvl.noteOn();
    }

    void stopNote (float, bool allowTailOff) override
    {
        if (allowTailOff) { updateEnvs(); ampEnv.noteOff(); fltEnvl.noteOff(); }
        else { ampEnv.reset(); fltEnvl.reset(); clearCurrentNote(); }
    }

    void pitchWheelMoved (int newValue) override { bend = (newValue - 8192) / 8192.0f * 2.0f; }
    void controllerMoved (int, int) override {}

    void renderNextBlock (juce::AudioBuffer<float>& out, int start, int num) override
    {
        if (getCurrentlyPlayingNote() < 0) return;

        const float sr = (float) getSampleRate();
        const int   w1 = (int) v (osc1Wave), w2 = (int) v (osc2Wave);
        const int   n  = juce::jlimit (1, 5, (int) v (unison));
        const float kSpread = v (spread), kO2 = v (osc2Level), kSub = v (subLevel), kNoise = v (noiseLevel);
        const float kSemi2 = v (osc2Semi) + v (osc2Detune) / 100.0f;
        const float kCut = v (cutoff), kEnv = v (fltEnv), kKey = v (keyTrack);
        const float kLfoRate = v (lfoRate), kLfoFilt = v (lfoDepth), kLfoPitch = v (lfoPitch);
        const float q = v (res);
        const float norm = 0.5f / std::sqrt ((float) n);

        float ratio[5], gl[5], gr[5];
        for (int u = 0; u < n; ++u)
        {
            const float off = n > 1 ? ((float) u / (float) (n - 1)) * 2.0f - 1.0f : 0.0f;
            ratio[u] = std::exp2 (off * kSpread / 1200.0f);
            const float pan = 0.5f + off * 0.4f;
            gl[u] = std::cos (pan * juce::MathConstants<float>::halfPi);
            gr[u] = std::sin (pan * juce::MathConstants<float>::halfPi);
        }
        for (auto& f : filt) f.setResonance (q);

        for (int i = 0; i < num; ++i)
        {
            lfoPh += kLfoRate / sr; if (lfoPh >= 1.0f) lfoPh -= 1.0f;
            const float lfo = std::sin (juce::MathConstants<float>::twoPi * lfoPh);

            const float semi = baseNote + bend + lfo * kLfoPitch * 0.5f;
            const float f1 = (float) juce::MidiMessage::getMidiNoteInHertz (0) * std::exp2 (semi / 12.0f);
            const float f2 = f1 * std::exp2 (kSemi2 / 12.0f);

            float l = 0.0f, r = 0.0f;
            for (int u = 0; u < n; ++u)
            {
                const float s = oscSample (w1, ph1[u], f1 * ratio[u] / sr)
                              + oscSample (w2, ph2[u], f2 * ratio[u] / sr) * kO2;
                l += s * gl[u] * norm; r += s * gr[u] * norm;
            }
            if (kSub > 0.0f)
            {
                const float s = std::sin (juce::MathConstants<float>::twoPi * subPh) * kSub * 0.5f;
                subPh += f1 * 0.5f / sr; if (subPh >= 1.0f) subPh -= 1.0f;
                l += s; r += s;
            }
            if (kNoise > 0.0f)
            {
                const float s = (rng.nextFloat() * 2.0f - 1.0f) * kNoise * 0.4f;
                l += s; r += s;
            }

            const float fe = fltEnvl.getNextSample();
            if ((i & 7) == 0)
            {
                const float oct = kEnv * fe * 5.0f + lfo * kLfoFilt * 2.0f + kKey * (semi - 60.0f) / 12.0f;
                const float fc = juce::jlimit (20.0f, sr * 0.45f, kCut * std::exp2 (oct));
                for (auto& f : filt) f.setCutoffFrequency (fc);
            }
            l = filt[0].processSample (0, l);
            r = filt[1].processSample (0, r);

            const float amp = ampEnv.getNextSample() * vel;
            out.addSample (0, start + i, l * amp);
            if (out.getNumChannels() > 1) out.addSample (1, start + i, r * amp);

            if (! ampEnv.isActive()) { clearCurrentNote(); break; }
        }
    }

private:
    float v (P p) const { return ptr[p]->load(); }

    void updateEnvs()
    {
        ampEnv.setParameters ({ v (aA), v (aD), v (aS), v (aR) });
        fltEnvl.setParameters ({ v (fA), v (fD), v (fS), v (fR) });
    }

    std::atomic<float>* ptr[numParams] {};
    juce::ADSR ampEnv, fltEnvl;
    juce::dsp::StateVariableTPTFilter<float> filt[2];
    juce::Random rng;
    float ph1[5] {}, ph2[5] {}, subPh = 0, lfoPh = 0, baseNote = 60, vel = 1, bend = 0;
};
}
