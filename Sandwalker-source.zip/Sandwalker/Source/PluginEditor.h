#pragma once
#include "PluginProcessor.h"

class SandwalkerEditor : public juce::AudioProcessorEditor
{
public:
    explicit SandwalkerEditor (SandwalkerProcessor&);
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    struct Knob  { juce::Slider s; juce::Label l; std::unique_ptr<SA> a; };
    struct Group { juce::String title; std::vector<std::unique_ptr<Knob>> knobs; };

    SandwalkerProcessor& proc;
    std::vector<Group> groups;
    juce::ComboBox presetBox, wave1Box, wave2Box;
    juce::TextButton prevBtn { "<" }, nextBtn { ">" };
    std::unique_ptr<CA> w1a, w2a;

    int rowY (int g) const { return 62 + g * 132; }
};
