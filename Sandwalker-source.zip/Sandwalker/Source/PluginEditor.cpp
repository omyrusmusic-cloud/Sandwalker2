#include "PluginEditor.h"

SandwalkerEditor::SandwalkerEditor (SandwalkerProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    using namespace sw;
    const juce::Colour sand (0xffe0a03c), text (0xffd8c9a8);

    auto addGroup = [&] (const char* title, std::initializer_list<P> list)
    {
        Group g; g.title = title;
        for (auto pid : list)
        {
            auto k = std::make_unique<Knob>();
            k->s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
            k->s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 70, 16);
            k->s.setColour (juce::Slider::rotarySliderFillColourId, sand);
            k->s.setColour (juce::Slider::thumbColourId, sand);
            k->s.setColour (juce::Slider::textBoxTextColourId, text);
            k->s.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
            k->l.setText (names[pid], juce::dontSendNotification);
            k->l.setJustificationType (juce::Justification::centred);
            k->l.setColour (juce::Label::textColourId, text);
            addAndMakeVisible (k->s); addAndMakeVisible (k->l);
            k->a = std::make_unique<SA> (proc.apvts, ids[pid], k->s);
            g.knobs.push_back (std::move (k));
        }
        groups.push_back (std::move (g));
    };

    addGroup ("OSCILLATORS",    { osc2Detune, osc2Level, osc2Semi, subLevel, noiseLevel, unison, spread });
    addGroup ("FILTER / LFO",   { cutoff, res, fltEnv, keyTrack, lfoRate, lfoDepth, lfoPitch });
    addGroup ("ENVELOPES",      { aA, aD, aS, aR, fA, fD, fS, fR });
    addGroup ("EFFECTS / OUT",  { chorus, delayMix, delayTime, delayFb, reverbMix, reverbSize, master });

    for (auto* b : { &wave1Box, &wave2Box }) { b->addItemList ({ "Sine", "Tri", "Saw", "Square" }, 1); addAndMakeVisible (b); }
    w1a = std::make_unique<CA> (proc.apvts, ids[osc1Wave], wave1Box);
    w2a = std::make_unique<CA> (proc.apvts, ids[osc2Wave], wave2Box);

    for (int i = 0; i < proc.getNumPrograms(); ++i) presetBox.addItem (proc.getProgramName (i), i + 1);
    presetBox.setSelectedId (proc.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.onChange = [this] { proc.setCurrentProgram (presetBox.getSelectedId() - 1); };
    prevBtn.onClick = [this] { presetBox.setSelectedId (juce::jmax (1, presetBox.getSelectedId() - 1), juce::sendNotification); };
    nextBtn.onClick = [this] { presetBox.setSelectedId (juce::jmin (presetBox.getNumItems(), presetBox.getSelectedId() + 1), juce::sendNotification); };
    addAndMakeVisible (presetBox); addAndMakeVisible (prevBtn); addAndMakeVisible (nextBtn);

    setSize (820, 600);
}

void SandwalkerEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1b1612));
    g.setColour (juce::Colour (0xffe0a03c));
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    g.drawText ("SANDWALKER", getWidth() - 160, 8, 150, 30, juce::Justification::centredRight);
    g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
    g.setColour (juce::Colour (0xff9c8a66));
    for (size_t i = 0; i < groups.size(); ++i)
    {
        g.drawText (groups[i].title, 14, rowY ((int) i), 300, 16, juce::Justification::left);
        g.drawHorizontalLine (rowY ((int) i) + 17, 14.0f, (float) getWidth() - 14.0f);
    }
}

void SandwalkerEditor::resized()
{
    prevBtn.setBounds (10, 10, 34, 28);
    presetBox.setBounds (48, 10, 280, 28);
    nextBtn.setBounds (332, 10, 34, 28);
    wave1Box.setBounds (390, 10, 100, 28);
    wave2Box.setBounds (498, 10, 100, 28);

    const int colW = (getWidth() - 20) / 8;
    for (size_t gi = 0; gi < groups.size(); ++gi)
        for (size_t ki = 0; ki < groups[gi].knobs.size(); ++ki)
        {
            auto& k = *groups[gi].knobs[ki];
            const int x = 10 + (int) ki * colW, y = rowY ((int) gi);
            k.l.setBounds (x, y + 22, colW, 16);
            k.s.setBounds (x + 8, y + 38, colW - 16, 88);
        }
}
